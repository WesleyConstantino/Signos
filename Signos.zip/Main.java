import java.util.Scanner;

class Main {
  public static void main(String[] args) {
   System.out.println("Digite o mês em que você nasceu");
   Scanner mes = new Scanner (System.in);
    String a = mes.next();
    if(a.equals("janeiro")){
          System.out.println("Seu signo é aquário");
    }
     else if(a.equals("fevereiro")){
          System.out.println("Seu signo é peixes");
      }
    else if(a.equals("março")){
          System.out.println("Seu signo é aires");
       }
    else if(a.equals("abril")){
      System.out.println("Seu signo é touro");
    }
    else if(a.equals("maio")){
      System.out.println("Seu signo é gêmios");
    }
    else if(a.equals("junho")){
      System.out.println("Seu signo é câncer");
    }
    else if(a.equals("julho")){
      System.out.println("Seu signo é leão");
    }
    else if(a.equals("agosto")){
      System.out.println("Seu signo é virgem");
    }
    else if(a.equals("setembro")){
      System.out.println("Seu signo é libra");
    }
    else if(a.equals("outubro")){
      System.out.println("Seu signo é escorpião");
    }
    else if(a.equals("novembro")){
      System.out.println("Seu signo é sagitário");
    }
    else if(a.equals("dezembro")){
      System.out.println("Seu signo é capricórnio");
    }
    else{
      System.out.println("Mês inválido");
      }
  }
}